

<?php $__env->startSection('content'); ?>
<div class="container mt-3">
    <h1>Edição de Finalidade</h1>
    <hr>
    <div class="col-md-8 offset-md-2">
        <form action="<?php echo e(route('usage.update', $usage->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <fieldset>
                <div class="row mb-3 form-floating">
                    <input class="form-control" type="text" name="name" id="name" placeholder="" value="<?php echo e($usage->name); ?>">
                    <label for="name">Nome</label>

                    <span class="text-danger">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>
                </div>

                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left me-2"></i>Voltar</a>  
                <button type="submit" class="btn btn-success"><i class="fas fa-save me-2"></i>Salvar Alterações</button>
            </fieldset>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\marco\Desktop\projetos php\imobiliaria\resources\views/usage/edit.blade.php ENDPATH**/ ?>