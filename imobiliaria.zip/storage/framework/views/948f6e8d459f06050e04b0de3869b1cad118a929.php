
<h2>Olá, <?php echo e($user->name); ?></h2>

<hr>

<p>
    Esta é uma aplicação que simula o funcionamento de um sistema de imobiliária <br>
    Obrigado por testa-la <br>
    Encontrou algum bug ? Responda esta mensagem com o problema encontrado.
</p>

<hr>
Email enviado em <?php echo e(date('d/m/Y H:i:s')); ?> para: <?php echo e($user->email); ?><?php /**PATH C:\Users\marco\Desktop\projetos php\imobiliaria\resources\views/mail/visit.blade.php ENDPATH**/ ?>