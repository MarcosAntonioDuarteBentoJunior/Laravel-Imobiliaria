<nav class="navbar navbar-expand-lg navbar-light bg-light py-3">
    <div class="container">
        <a class="navbar-brand align-items-center" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('/img/logo.png')); ?>" class="img-fluid me-3" alt="logo">Imobiliária</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="<?php echo e(route('home')); ?>">Home</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Imóveis
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <?php
                            $categories = App\Models\Category::all();
                            $usages = App\Models\Usage::all();
                        ?>

                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('realty.category', $category->id)); ?>"><?php echo e($category->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if(auth()->guard()->check()): ?>
                            <?php if(!strcmp(Auth::user()->role, 'admin')): ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('realty.create')); ?>">Novo imóvel</a></li>
                            <?php endif; ?>
                        <?php endif; ?>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown2" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Negócios
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown2">
                        <?php
                            $usages = App\Models\Usage::all();
                        ?>

                        <?php $__currentLoopData = $usages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('realty.usage', $usage->id)); ?>"><?php echo e($usage->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" <?php if(!Route::is('home')): ?> style="display: none;" <?php endif; ?> href="#scrollspyHeading1">Contato</a>
                </li>
            </ul>
            <div class="d-flex">
                <?php if(Auth::check()): ?>
                    <?php if(!strcmp(Auth::user()->role, 'admin')): ?>
                        <div class="d-flex">
                            <div class="align-self-center">
                                <li class="nav-item list-unstyled align-self-center">
                                    <a href="<?php echo e(route('category.dashboard')); ?>">
                                        <i class="fas fa-users-cog align-self-center" title="Painel Administrativo"></i>
                                    </a>
                                </li>
                            </div>
                            <li class="nav-item dropdown list-unstyled">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-user-shield me-1"></i><?php echo e(Auth::user()->name); ?>

                                </a>

                                <ul class="dropdown-menu list-unstyled" aria-labelledby="navbarDropdown2">
                                    <li>
                                        <form action="<?php echo e(route('logout')); ?>" class="align-self-center ms-5" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn">
                                                <span class="me-auto text-center">Sair</span><i class="fas fa-sign-out-alt ms-2"></i>
                                            </button>
                                        </form>
                                    </li>
                                </ul>
                            </li>
                        </div>
                    <?php else: ?>
                        <div>
                            <li class="nav-item dropdown list-unstyled">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-user-tag me-1"></i><?php echo e(Auth::user()->name); ?>

                                </a>

                                <ul class="dropdown-menu list-unstyled" aria-labelledby="navbarDropdown2">
                                    <li>
                                        <form action="<?php echo e(route('logout')); ?>" class="align-self-center ms-5" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn">
                                                <span class="me-auto text-center">Sair</span><i class="fas fa-sign-out-alt ms-2"></i>
                                            </button>
                                        </form>
                                    </li>
                                </ul>
                            </li>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="me-3">
                        <a href="<?php echo e(route('login')); ?>" class="text-decoration-none">
                            <i class="fas fa-sign-in-alt me-1"></i>Login
                        </a>
                    </div>
                    <div>
                        <a href="<?php echo e(route('register')); ?>" class="text-decoration-none">
                            <i class="fas fa-user me-1"></i>Cadastre-se
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav><?php /**PATH C:\Users\marco\Desktop\projetos php\imobiliaria\resources\views/layouts/header.blade.php ENDPATH**/ ?>