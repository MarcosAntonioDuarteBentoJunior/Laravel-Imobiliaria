

<?php $__env->startSection('content'); ?>
<section id="info">
    <div class="container mt-4 py-3 text-white">
        <?php if(Session::get('success')): ?>
            <div class="alert alert-success w-100 text-center">
                <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-12 col-md-5 col-lg-4">
                <?php $__currentLoopData = $realty->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo e(asset('storage/' . $photo->image_path)); ?>" class="card-img-top h-100" alt="...">
                <?php break; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-12 col-md-7 col-lg-8 py-3 text-dark">
                <h2 class="mb-3 text-uppercase">
                    <?php echo e($realty->name); ?>

                </h2>
                <p class="mb-3">
                    <?php echo e($realty->description); ?>

                </p>
                <div class="text-center d-flex justify-content-between mb-4">
                    <div>
                        <i class="fas fa-tv me-1"></i><?php echo e($realty->rooms); ?> sala(s)
                    </div>

                    <div>
                        <i class="fas fa-bed me-1"></i><?php echo e($realty->bedrooms); ?> quarto(s)
                    </div>

                    <div>
                        <i class="fas fa-bath me-1"></i><?php echo e($realty->bathrooms); ?> banheiro(s)
                    </div>

                    <div>
                        <i class="fas fa-warehouse me-1"></i><?php echo e($realty->parking); ?> vaga(s) de garagem
                    </div>

                    <div>
                        <i class="fas fa-vector-square me-1"></i><?php echo e(number_format($realty->area, 2, ',', '.')); ?> m²
                    </div>
                </div>

                <div class="d-flex mb-4">
                    <div class="me-5">
                        <p class="text-primary">Valor: R$ <?php echo e(number_format($realty->value, 2, ',', '.')); ?></p>
                    </div>
                    <div>
                        <p class="text-warning">
                            <?php echo e($realty->category->name); ?> | <?php echo e($realty->usage->name); ?>

                        </p>
                    </div>
                </div>

                <a href="<?php echo e(route('appointment', $realty->slug )); ?>" class="btn btn-warning px-3 py-3">
                    <i class="fas fa-edit"></i> <span class="align-self-center">Agende uma visita</span>
                </a>
            </div>
        </div>
    </div>
</section>

<section id="gallery">
    <div class="container mt-5">
        <h2 class="text-center">Fotos</h2>
        <hr class="mb-3">
        <div class="row justify-content-around">
            <?php if($realty->photos->isEmpty()): ?>
                <div class="alert alert-info">
                    Este imóvel naõ possui fotos.
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $realty->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-md-6 col-lg-4 col-xl-3 mb-3 mb-md-4">
                        <div class="card h-100 border-0">
                            <img src="<?php echo e(asset('storage/' . $photo->image_path)); ?>" class="card-img-top zoom" alt="...">
                            <?php if(Auth::check() && Auth::user()->can('delete', $photo)): ?>
                                <div class="card-body text-center">
                                    <form action="<?php echo e(route('photo.remove')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="photoName" value="<?php echo e($photo->image_path); ?>">
                    
                                        <button type="submit" class="btn btn-outline-danger">Remover</button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/medium-zoom.min.js')); ?>"></script>
    <script>
        mediumZoom('.zoom', {
            margin: 50,
            background: '#000'
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\marco\Desktop\projetos php\imobiliaria\resources\views/realty/show.blade.php ENDPATH**/ ?>