

<?php $__env->startSection('content'); ?>
    <section id="results">
        <div class="container mt-3">
            <div class="row">
                <?php if(Session::get('success')): ?>
                    <div class="alert alert-success text-center">
                        <?php echo e(Session::get('success')); ?>

                    </div>
                <?php endif; ?>
    
                <?php if(Session::get('fail')): ?>
                    <div class="alert alert-danger text-center">
                        <?php echo e(Session::get('fail')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section id="categories">
        <div class="container mt-3">
            <h2 class="text-center">Categorias</h2>
            <hr class="mb-3 text-primary">
            <div class="row">
                <?php if($categories->isEmpty()): ?>
                    <div class="alert alert-info">
                        Não existem categorias para listar.
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped justify-content-around">
                            <thead>
                                <th scope="col">Categoria</th>
                                <th scope="col">Imóveis Cadastrados</th>
                                <th scope="col">Criado em</th>
                                <th scope="col">Ações</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($category->name); ?></td>
                                        <td><?php echo e($category->realties->count()); ?></td>
                                        <td><?php echo e(date('d/m/Y', strtotime($category->created_at))); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('category.edit', $category->id)); ?>" class="text-decoration-none">
                                                <i class="fas fa-pencil-alt me-2" title="Editar"></i>
                                            </a>

                                            <a href="#" class="text-decoration-none text-danger" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($category->id); ?>">
                                                <i class="fas fa-trash" title="Excluir"></i>
                                            </a>

                                            <!-- Modal -->
                                            <div class="modal fade" id="exampleModal<?php echo e($category->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Confirmar Ação</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            Tem certeza que deseja remover a categoria <?php echo e($category->name); ?> ?
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Cancelar</button>
                                                            <form action="<?php echo e(route('category.destroy', $category->id)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>

                                                                <button type="submit" class="btn btn-outline-danger">Confirmar</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>

                <div class="justify-content-start">
                    <a href="<?php echo e(route('category.create')); ?>" class="btn btn-success mb-2">Nova Categoria</a>
                </div>
                <div class="text-center mt-3">
                    <?php echo $categories->links(); ?>

                </div>
            </div>
        </div>
    </section>

    <section id="usages">
        <div class="container mt-3">
            <div class="row">
                <h2 class="text-center">Finalidades</h2>
                <hr class="mb-3 text-primary">
                <?php if($usages->isEmpty()): ?>
                    <div class="alert alert-info">
                        Não existem finalidades para listar.
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped justify-content-around">
                            <thead>
                                <th scope="col">Finalidade</th>
                                <th scope="col">Imóveis Cadastrados</th>
                                <th scope="col">Criado em</th>
                                <th scope="col">Ações</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $usages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($usage->name); ?></td>
                                        <td><?php echo e($usage->realties->count()); ?></td>
                                        <td><?php echo e(date('d/m/Y', strtotime($usage->created_at))); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('usage.edit', $usage->id)); ?>" class="text-decoration-none">
                                                <i class="fas fa-pencil-alt me-2" title="Editar"></i>
                                            </a>

                                            <a href="#" class="text-decoration-none" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($usage->id * 10); ?>">
                                                <i class="fas fa-trash text-danger"title="Excluir"></i>
                                            </a>

                                            <!-- Modal -->
                                            <div class="modal fade" id="exampleModal<?php echo e($usage->id * 10); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Confirmar Ação</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            Tem certeza que deseja remover a finalidade <?php echo e($usage->name); ?> ?
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Cancelar</button>
                                                            <form action="<?php echo e(route('usage.destroy', $usage->id)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>

                                                                <button type="submit" class="btn btn-outline-danger">Confirmar</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>

                <div class="justify-content-start">
                    <a href="<?php echo e(route('usage.create')); ?>" class="btn btn-success mb-2">Nova Finalidade</a>
                </div>
                <div class="text-center mt-4">
                    <?php echo $usages->links(); ?>

                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\marco\Desktop\projetos php\imobiliaria\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>