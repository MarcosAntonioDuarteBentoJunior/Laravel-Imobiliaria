<h3>
    mensagem de: <?php echo e($email['name']); ?>

</h3>

<hr>

<p>
    <?php echo e($email['message']); ?>

</p>

<hr>

Email enviado em <?php echo e(date('d/m/Y h:i:s')); ?> por: <?php echo e($email['email']); ?>

<?php /**PATH C:\Users\marco\Desktop\projetos php\imobiliaria\resources\views/mail/contact.blade.php ENDPATH**/ ?>