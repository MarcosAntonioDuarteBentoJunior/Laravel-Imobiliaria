<div>
    <section class="p-3 border-top border-dark">
        <div class="row d-flex align-items-center">
            <div class="col-md-7 col-lg-8 text-center text-md-start">
                <!-- Copyright -->
                <div class="p-3">
                © 2021 Copyright: Imobiliária - Todos o direitos reservados.
                </div>
                <!-- Copyright -->
            </div>

            <div class="col-md-5 col-lg-4 ml-lg-0 text-center text-md-end">
                <a
                    class="btn btn-outline-light btn-floating m-1"
                    class="text-white"
                    role="button"
                    ><i class="fab fa-facebook-f"></i
                ></a>

                <a
                    class="btn btn-outline-light btn-floating m-1"
                    class="text-white"
                    role="button"
                    ><i class="fab fa-twitter"></i
                ></a>

                <a
                    class="btn btn-outline-light btn-floating m-1"
                    class="text-white"
                    role="button"
                    ><i class="fab fa-google"></i
                ></a>

                <a
                    class="btn btn-outline-light btn-floating m-1"
                    class="text-white"
                    role="button"
                    ><i class="fab fa-instagram"></i
                ></a>
            </div>
        </div>
    </section>
</div>
